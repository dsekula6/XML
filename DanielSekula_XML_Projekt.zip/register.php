<?php

$username="";
$password="";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	

	if (empty($_POST["username"]))  {
        	echo "Korisnicki račun nije unesen.";
		
    		}
	else if (empty($_POST["password"]))  {
        	echo "Lozinka nije unesena.";
		
    		}
	else {
		$username= $_POST["username"];
		$password= $_POST["password"];
	
		dodaj($username,$password);
	}
}

function dodaj($username, $password) {


    // Open and parse the XML file
    $xml = simplexml_load_file("users.xml");

    foreach ($xml->user as $usr) {
        $usrn = $usr->username;
     $usrp = $usr->password;
     if($usrn==$username){
         
        echo "<script type='text/javascript'>confirm('vec postoji korisnik s tim korisnickim imenom!');</script>";
            return;
        }
    }
    
        // Create a child in the first topic node
        $child = $xml->addChild("user");
        // Add the text attribute
        $child->addChild("username", $username);
        $child->addChild("password", $password);
        // You can either display the new XML code with echo or store it in a file.
        // Store new XML code in questions.xml
        // nesto drugo
        $dom = new DOMDocument("1.0");
        $dom->preserveWhiteSpace = false;
        $dom->formatOutput = true;
        $dom->loadXML($xml->asXML());
        $dom->save("users.xml");

        return;


}
    



?>

<!DOCTYPE html>    
<html>    
<head>    
    <title>Register Form</title>
    <link rel="stylesheet" href="style.css">
</head>    
<body>    
    <h2>Register Page</h2><br>    
    <div class="login">    
    <form id="login" method="post" action="register.php">    
        <label><b>User Name     
        </b>    
        </label>    
        <input type="text" name="username" id="Uname" placeholder="Username">    
        <br><br>    
        <label><b>Password     
        </b>    
        </label>    
        <input type="Password" name="password" id="Pass" placeholder="Password">    
        <br><br>    
        <button type="submit" name="log" id="log">Register Here</button>       
        <br><br> 
        <a href="login.php">Login</a>  
    </form>     
</div>    
</body>    
</html>  